package DIV.credit.client.draft;

import DIV.credit.Credit;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.forge.ForgeTypes;
import mezz.jei.api.gui.IRecipeLayoutDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotView;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.IRecipeManager;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.ModList;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * 任意カテゴリで使える汎用 Draft。
 * 既存レシピ 1 個を probe して slot views から SlotKind を自動推定。
 * toRecipeInstance は null 固定 → 常に FALLBACK 表示 + ユーザー編集は overlay で視覚反映。
 * emit はベストエフォート（コメント形式 + 検出済み中身列挙）。
 */
public final class GenericDraft implements RecipeDraft {

    private final RecipeType<?> jeiType;
    private final SlotKind[] kinds;
    private final IngredientSpec[] slots;

    // GT 系か（gtceu + StarT-Core 等の addon。recipe class が GTRecipe 派生）
    private final boolean isGt;
    // Mek 系か（mekanism + EvolvedMekanism 等の extension。category が BaseRecipeCategory 派生）
    private final boolean isMek;
    // IE 系か（immersiveengineering 本体 + 派生。category が IERecipeCategory 派生）
    private final boolean isIe;
    // Create 系か（category が CreateRecipeCategory 派生）
    private final boolean isCreate;
    // Create heat 設定 (mixing/compacting/packing のみ意味あり)
    private DIV.credit.client.draft.create.HeatLevel heatLevel = DIV.credit.client.draft.create.HeatLevel.NONE;
    // Create keepHeldItem 設定 (item_application/deploying のみ意味あり)
    private boolean keepHeldItem = false;
    private long durationValue;
    private long eutValue;
    private final java.util.LinkedHashMap<String, Long> intDataValues = new java.util.LinkedHashMap<>();

    private GenericDraft(RecipeType<?> jeiType, SlotKind[] kinds,
                         boolean isGt, boolean isMek, boolean isIe, boolean isCreate,
                         long duration, long eut, java.util.LinkedHashMap<String, Long> intData) {
        this.jeiType = jeiType;
        this.kinds   = kinds;
        this.slots   = new IngredientSpec[kinds.length];
        for (int i = 0; i < slots.length; i++) slots[i] = IngredientSpec.EMPTY;
        this.isGt = isGt;
        this.isMek = isMek;
        this.isIe = isIe;
        this.isCreate = isCreate;
        this.durationValue = duration;
        this.eutValue = eut;
        if (intData != null) this.intDataValues.putAll(intData);
    }

    /**
     * sample recipe を 1 個取って slot kinds を推定。
     * 0 supported slot や例外で null → caller がアン対応扱い。
     */
    @Nullable
    public static <T> GenericDraft tryCreate(IRecipeCategory<T> cat, IRecipeManager rm) {
        try {
            RecipeType<T> rt = cat.getRecipeType();
            var sample = rm.createRecipeLookup(rt).includeHidden().get().findFirst();
            if (sample.isEmpty()) {
                Credit.LOGGER.info("[CraftPattern] GenericDraft: no sample recipe for {}", rt.getUid());
                return null;
            }
            IFocusGroup empty = mezz.jei.api.runtime.IJeiRuntime.class.cast(
                DIV.credit.jei.CraftPatternJeiPlugin.runtime).getJeiHelpers().getFocusFactory().getEmptyFocusGroup();
            IRecipeLayoutDrawable<?> drawable = rm.createRecipeLayoutDrawable(cat, sample.get(), empty).orElse(null);
            if (drawable == null) {
                Credit.LOGGER.info("[CraftPattern] GenericDraft: cannot build sample drawable for {}", rt.getUid());
                return null;
            }

            List<IRecipeSlotView> views = drawable.getRecipeSlotsView().getSlotViews();
            int slotCount = views.size();
            SlotKind[] kinds = new SlotKind[slotCount];
            for (int i = 0; i < slotCount; i++) {
                kinds[i] = inferKind(views.get(i));
            }
            // Multi-sample probe: first sample で型が決まらないスロットは複数サンプル舐めて補完
            // （alloy_blast_smelter 等、最初のレシピで fluid slot の一部が使われない場合への対処）
            int detected = countNonNull(kinds);
            if (detected < slotCount) {
                List<T> moreSamples = rm.createRecipeLookup(rt).includeHidden().get()
                    .limit(30).toList();
                for (T extra : moreSamples) {
                    if (countNonNull(kinds) >= slotCount) break;
                    try {
                        IRecipeLayoutDrawable<?> d2 = rm.createRecipeLayoutDrawable(cat, extra, empty).orElse(null);
                        if (d2 == null) continue;
                        List<IRecipeSlotView> v2 = d2.getRecipeSlotsView().getSlotViews();
                        for (int i = 0; i < Math.min(v2.size(), slotCount); i++) {
                            if (kinds[i] != null) continue;
                            SlotKind k = inferKind(v2.get(i));
                            if (k != null) kinds[i] = k;
                        }
                    } catch (Exception ignored) {}
                }
            }
            int supported = countNonNull(kinds);
            if (supported == 0) {
                Credit.LOGGER.info("[CraftPattern] GenericDraft: no item/fluid/gas slots in {} (views={})",
                    rt.getUid(), slotCount);
                return null;
            }
            // 残った null は role でフォールバック（OUTPUT → ITEM_OUTPUT、その他 → ITEM_INPUT）
            for (int i = 0; i < kinds.length; i++) {
                if (kinds[i] == null) {
                    var role = views.get(i).getRole();
                    kinds[i] = (role == mezz.jei.api.recipe.RecipeIngredientRole.OUTPUT)
                        ? SlotKind.ITEM_OUTPUT : SlotKind.ITEM_INPUT;
                }
            }
            // システム判定（modId 不問）
            boolean isGt  = DIV.credit.client.draft.gt.GTSupport.isGtCategory(cat)
                && net.minecraftforge.fml.ModList.get().isLoaded("gtceu");
            boolean isMek = DIV.credit.client.draft.mek.MekanismSupport.isMekCategory(cat)
                && net.minecraftforge.fml.ModList.get().isLoaded("mekanism");
            boolean isIe  = DIV.credit.client.draft.ie.IESupport.isIeCategory(cat)
                && net.minecraftforge.fml.ModList.get().isLoaded("immersiveengineering");
            boolean isCreate = DIV.credit.client.draft.create.CreateSupport.isCreateCategory(cat)
                && net.minecraftforge.fml.ModList.get().isLoaded("create");
            long durationInit = 0, eutInit = 0;
            java.util.LinkedHashMap<String, Long> intDataInit = new java.util.LinkedHashMap<>();
            if (isGt) {
                var meta = DIV.credit.client.draft.gt.GTSupport.probeMetadata(sample.get(), rt.getUid());
                durationInit = meta.duration;
                eutInit = meta.eut;
                intDataInit.putAll(meta.intData);
                Credit.LOGGER.info("[CraftPattern] GenericDraft GT metadata for {}: duration={} EUt={} intData={}",
                    rt.getUid(), durationInit, eutInit, intDataInit);
            }
            Credit.LOGGER.info("[CraftPattern] GenericDraft created for {}: {} slots ({} supported) isGt={} isMek={} isIe={} isCreate={}",
                rt.getUid(), views.size(), supported, isGt, isMek, isIe, isCreate);
            return new GenericDraft(rt, kinds, isGt, isMek, isIe, isCreate, durationInit, eutInit, intDataInit);
        } catch (Exception e) {
            Credit.LOGGER.warn("[CraftPattern] GenericDraft probe failed for {}: {}",
                cat.getRecipeType().getUid(), e.toString());
            return null;
        }
    }

    private static int countNonNull(SlotKind[] arr) {
        int n = 0;
        for (SlotKind k : arr) if (k != null) n++;
        return n;
    }

    /** slot view の role + ingredient type → SlotKind。判定不可なら null。 */
    @Nullable
    private static SlotKind inferKind(IRecipeSlotView view) {
        RecipeIngredientRole role = view.getRole();
        boolean output = role == RecipeIngredientRole.OUTPUT;
        // ingredient type は最初に見つけたもので決める
        for (Object obj : view.getAllIngredients().toList()) {
            if (!(obj instanceof ITypedIngredient<?> ti)) continue;
            String typeUid = ti.getType().getUid();
            if (VanillaTypes.ITEM_STACK.getUid().equals(typeUid)) {
                return output ? SlotKind.ITEM_OUTPUT : SlotKind.ITEM_INPUT;
            }
            if (ForgeTypes.FLUID_STACK.getUid().equals(typeUid)) {
                return output ? SlotKind.FLUID_OUTPUT : SlotKind.FLUID_INPUT;
            }
            if (ModList.get().isLoaded("mekanism")
                && "mekanism.api.chemical.gas.GasStack".equals(typeUid)) {
                return output ? SlotKind.GAS_OUTPUT : SlotKind.GAS_INPUT;
            }
        }
        return null;
    }

    @Override public int slotCount() { return slots.length; }
    @Override public IngredientSpec getSlot(int i) { return slots[i]; }
    @Override public RecipeType<?> recipeType() { return jeiType; }
    @Override public boolean usesGtElectricity() { return isGt && eutValue > 0; }

    @Override
    public boolean canRequireHeat() {
        if (!isCreate) return false;
        String path = jeiType.getUid().getPath();
        // JEI category UID ベース。packing は実は compacting レシピで heat 可。
        return "mixing".equals(path) || "compacting".equals(path) || "packing".equals(path);
    }

    @Override public DIV.credit.client.draft.create.HeatLevel getHeatLevel() { return heatLevel; }

    @Override public void setHeatLevel(DIV.credit.client.draft.create.HeatLevel level) {
        if (level != null) this.heatLevel = level;
    }

    @Override
    public boolean canKeepHeldItem() {
        if (!isCreate) return false;
        String path = jeiType.getUid().getPath();
        return "item_application".equals(path) || "deploying".equals(path);
    }

    @Override public boolean isKeepHeldItem() { return keepHeldItem; }

    @Override public void setKeepHeldItem(boolean value) { this.keepHeldItem = value; }

    @Override
    public SlotKind slotKind(int i) {
        if (i < 0 || i >= kinds.length) return SlotKind.ITEM_INPUT;
        return kinds[i];
    }

    /**
     * IRecipeLayoutDrawable の slot views を walk して、各 slot の displayed ingredient を draft に流し込む。
     * Item / Fluid / Gas (Mek 系) を識別。複数候補は最初を採用。
     * GT metadata (duration/EUt/intData) は recipe instance を probe して反映。
     */
    @Override
    public boolean loadFromRecipe(IRecipeLayoutDrawable<?> layout) {
        try {
            List<IRecipeSlotView> views = layout.getRecipeSlotsView().getSlotViews();
            int n = Math.min(views.size(), slots.length);
            int loaded = 0;
            for (int i = 0; i < n; i++) {
                IngredientSpec spec = readSpecFromView(views.get(i));
                if (!spec.isEmpty()) {
                    slots[i] = spec;
                    loaded++;
                }
            }
            // GT metadata 反映
            if (isGt) {
                Object recipe = layout.getRecipe();
                if (recipe instanceof net.minecraft.world.item.crafting.Recipe<?> mcr) {
                    var meta = DIV.credit.client.draft.gt.GTSupport.probeMetadata(mcr, jeiType.getUid());
                    this.durationValue = meta.duration;
                    this.eutValue = meta.eut;
                    this.intDataValues.clear();
                    this.intDataValues.putAll(meta.intData);
                }
            }
            Credit.LOGGER.info("[CraftPattern] GenericDraft.loadFromRecipe {} → {}/{} slots",
                jeiType.getUid(), loaded, n);
            return loaded > 0;
        } catch (Exception e) {
            Credit.LOGGER.warn("[CraftPattern] GenericDraft.loadFromRecipe failed for {}: {}",
                jeiType.getUid(), e.toString());
            return false;
        }
    }

    /** Slot view の displayed ingredient を IngredientSpec に変換。複数候補 ITypedIngredient のうち最初を採用。 */
    private static IngredientSpec readSpecFromView(IRecipeSlotView view) {
        var displayed = view.getDisplayedIngredient();
        ITypedIngredient<?> ti;
        if (displayed.isPresent()) {
            ti = displayed.get();
        } else {
            // displayed なしなら all ingredients から最初の有効なものを探す
            ti = view.getAllIngredients()
                .filter(ITypedIngredient.class::isInstance)
                .map(o -> (ITypedIngredient<?>) o)
                .findFirst().orElse(null);
        }
        if (ti == null) return IngredientSpec.EMPTY;
        Object obj = ti.getIngredient();
        if (obj instanceof ItemStack stack && !stack.isEmpty()) {
            return new IngredientSpec.Item(stack.copy());
        }
        if (obj instanceof FluidStack fs && !fs.isEmpty()) {
            return new IngredientSpec.Fluid(fs.copy());
        }
        // Mek Gas: reflection で id + amount 抽出
        if (ModList.get().isLoaded("mekanism")
            && "mekanism.api.chemical.gas.GasStack".equals(ti.getType().getUid())) {
            try {
                var gasField = obj.getClass().getMethod("getType");
                Object gasType = gasField.invoke(obj);
                var idMethod = gasType.getClass().getMethod("getRegistryName");
                ResourceLocation id = (ResourceLocation) idMethod.invoke(gasType);
                var amtMethod = obj.getClass().getMethod("getAmount");
                long amount = (long) amtMethod.invoke(obj);
                if (id != null && amount > 0) {
                    return new IngredientSpec.Gas(id, (int) Math.min(amount, Integer.MAX_VALUE));
                }
            } catch (Exception ignored) {}
        }
        return IngredientSpec.EMPTY;
    }

    @Override
    public void setSlot(int i, IngredientSpec s) {
        if (i < 0 || i >= slots.length) return;
        if (s == null) s = IngredientSpec.EMPTY;
        if (!acceptsAt(i, s)) return;
        slots[i] = s;
    }

    /**
     * 通常は null → FALLBACK 表示。
     * GT カテゴリは空 recipe を構築（duration/EUt/data も適用）→ LdLib widgets が numeric を反映描画。
     */
    @Override
    public net.minecraft.world.item.crafting.Recipe<?> toRecipeInstance() {
        if (isGt) {
            return DIV.credit.client.draft.gt.GTSupport.tryBuildEmptyRecipe(
                jeiType.getUid(), durationValue, eutValue, intDataValues);
        }
        return null;
    }

    @Override
    public java.util.List<NumericField> numericFields() {
        if (!isGt) return java.util.List.of();
        java.util.List<NumericField> fields = new java.util.ArrayList<>();
        fields.add(new NumericField("Duration", NumericField.Kind.INT,
            () -> durationValue, v -> durationValue = (long) v, 1, Integer.MAX_VALUE));
        fields.add(new NumericField("EUt", NumericField.Kind.INT,
            () -> eutValue, v -> eutValue = (long) v, 0, Integer.MAX_VALUE));
        for (String key : intDataValues.keySet()) {
            fields.add(new NumericField(prettyDataLabel(key), NumericField.Kind.INT,
                () -> intDataValues.getOrDefault(key, 0L),
                v -> intDataValues.put(key, (long) v),
                0, Integer.MAX_VALUE));
        }
        return fields;
    }

    /** "ebf_temp" → "EBF Temp"、"solderMultiplier" → "Solder Multiplier" 等の軽い整形。 */
    private static String prettyDataLabel(String key) {
        if (key == null || key.isEmpty()) return key;
        // snake_case → Title Case
        if (key.contains("_")) {
            StringBuilder sb = new StringBuilder();
            for (String part : key.split("_")) {
                if (sb.length() > 0) sb.append(' ');
                if (!part.isEmpty()) sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
            }
            return sb.toString();
        }
        // camelCase → Title Case
        StringBuilder sb = new StringBuilder();
        sb.append(Character.toUpperCase(key.charAt(0)));
        for (int i = 1; i < key.length(); i++) {
            char c = key.charAt(i);
            if (Character.isUpperCase(c) && i > 0 && !Character.isUpperCase(key.charAt(i - 1))) sb.append(' ');
            sb.append(c);
        }
        return sb.toString();
    }

    @Override
    public String relativeOutputPath() {
        ResourceLocation rl = jeiType.getUid();
        return "generated/" + rl.getNamespace() + "/" + rl.getPath() + ".js";
    }

    /**
     * GT 系は KubeJS GT 共通形式、Mek 系は per-schema 形式。それ以外はコメント形式。
     */
    @Override
    public String emit(String recipeId) {
        boolean anyEdit = false;
        for (IngredientSpec s : slots) if (!s.isEmpty()) { anyEdit = true; break; }
        if (!anyEdit) return null;

        if (isGt) return emitGt(recipeId);
        if (isMek) {
            // 既知 Mek schema にマッチすれば schema 形式、それ以外（addon の独自カテゴリ等）は
            // 下のコメント skeleton にフォールバック
            String s = DIV.credit.client.draft.mek.MekanismKubeJSEmitter.emit(
                recipeId, jeiType.getUid(), slots, kinds);
            if (s != null) return s;
        }
        if (isIe) {
            String s = DIV.credit.client.draft.ie.IEKubeJSEmitter.emit(
                recipeId, jeiType.getUid(), slots, kinds);
            if (s != null) return s;
        }
        if (isCreate) {
            String s = DIV.credit.client.draft.create.CreateKubeJSEmitter.emit(
                recipeId, jeiType.getUid(), slots, kinds, heatLevel, keepHeldItem);
            if (s != null) return s;
        }
        return emitCommentSkeleton(recipeId);
    }

    /**
     * GT KubeJS: event.recipes.gtceu.<path>(id)
     *   .itemInputs(...) .inputFluids(...) .itemOutputs(...) .outputFluids(...)
     *   [.notConsumable(catalyst)]   <- GT_CATALYST 入力
     *   [.chancedOutput(stack, c, b)]<- GT_CHANCE 出力 (1000分率→×10)
     *   .duration(...) .EUt(...) [.addData(k,v) ...]
     */
    private String emitGt(String recipeId) {
        java.util.List<String> itemIn         = new java.util.ArrayList<>();
        java.util.List<String> fluidIn        = new java.util.ArrayList<>();
        java.util.List<String> itemOut        = new java.util.ArrayList<>();
        java.util.List<String> fluidOut       = new java.util.ArrayList<>();
        java.util.List<String> notConsumable  = new java.util.ArrayList<>();
        java.util.List<String> chancedItemOut = new java.util.ArrayList<>();
        java.util.List<String> chancedFlOut   = new java.util.ArrayList<>();
        for (int i = 0; i < slots.length; i++) {
            IngredientSpec s = slots[i];
            if (s.isEmpty()) continue;
            boolean catalyst = DIV.credit.client.draft.gt.GTEmitFormat.isCatalyst(s);
            boolean chance   = DIV.credit.client.draft.gt.GTEmitFormat.isChance(s);
            switch (kinds[i]) {
                case ITEM_INPUT -> {
                    String f = DIV.credit.client.draft.gt.GTEmitFormat.formatItem(s);
                    if (f == null) break;
                    if (catalyst) notConsumable.add(f);
                    else          itemIn.add(f);
                }
                case ITEM_OUTPUT -> {
                    String f = DIV.credit.client.draft.gt.GTEmitFormat.formatItem(s);
                    if (f == null) break;
                    if (chance) chancedItemOut.add(f + ", "
                        + DIV.credit.client.draft.gt.GTEmitFormat.chanceArgs(s));
                    else        itemOut.add(f);
                }
                case FLUID_INPUT -> {
                    String f = DIV.credit.client.draft.gt.GTEmitFormat.formatFluid(s);
                    if (f != null) fluidIn.add(f);
                }
                case FLUID_OUTPUT -> {
                    String f = DIV.credit.client.draft.gt.GTEmitFormat.formatFluid(s);
                    if (f == null) break;
                    if (chance) chancedFlOut.add(f + ", "
                        + DIV.credit.client.draft.gt.GTEmitFormat.chanceArgs(s));
                    else        fluidOut.add(f);
                }
                default -> {}  // gas は GT recipe には基本ないので無視
            }
        }

        // GT サブカテゴリは親 type 名を使う必要あり（chem_dyes → chemical_bath 等）
        String path = DIV.credit.client.draft.gt.GTSupport.resolveKubeJsRecipeName(jeiType.getUid());
        // KubeJS 経路は registered RecipeType の namespace を使う。
        // gtceu native も addon (StarT-Core 等) も addon の namespace で emit される。
        String ns = jeiType.getUid().getNamespace();
        StringBuilder sb = new StringBuilder();
        sb.append("    event.recipes.").append(ns).append('.').append(path)
          .append("('").append(recipeId).append("')\n");
        if (!itemIn.isEmpty())   sb.append("        .itemInputs(").append(String.join(", ", itemIn)).append(")\n");
        if (!fluidIn.isEmpty())  sb.append("        .inputFluids(").append(String.join(", ", fluidIn)).append(")\n");
        if (!itemOut.isEmpty())  sb.append("        .itemOutputs(").append(String.join(", ", itemOut)).append(")\n");
        if (!fluidOut.isEmpty()) sb.append("        .outputFluids(").append(String.join(", ", fluidOut)).append(")\n");
        for (String nc : notConsumable)   sb.append("        .notConsumable(").append(nc).append(")\n");
        for (String c  : chancedItemOut)  sb.append("        .chancedOutput(").append(c).append(")\n");
        for (String c  : chancedFlOut)    sb.append("        .chancedFluidOutput(").append(c).append(")\n");
        sb.append("        .duration(").append(durationValue).append(")\n");
        sb.append("        .EUt(").append(eutValue).append(")");
        // 既知の data パラメータを named method として追加
        if (intDataValues.containsKey("ebf_temp")) {
            sb.append("\n        .blastFurnaceTemp(").append(intDataValues.get("ebf_temp")).append(")");
        }
        // それ以外の data は addData(key, val) で
        for (var e : intDataValues.entrySet()) {
            if ("ebf_temp".equals(e.getKey())) continue;
            sb.append("\n        .addData('").append(e.getKey()).append("', ").append(e.getValue()).append(")");
        }
        sb.append(";\n");
        return sb.toString();
    }

    /** Mod 別 KubeJS 形式が分からないとき用のコメントスケルトン。 */
    private String emitCommentSkeleton(String recipeId) {
        StringBuilder sb = new StringBuilder();
        sb.append("    // Auto-generated draft for category ").append(jeiType.getUid()).append("\n");
        sb.append("    // recipeId: ").append(recipeId).append("\n");
        sb.append("    // TODO: convert to actual KubeJS recipe call (mod-specific)\n");
        sb.append("    /*\n");
        for (int i = 0; i < slots.length; i++) {
            sb.append("     *   slot[").append(i).append("] ").append(kinds[i].name()).append(": ");
            sb.append(describeSpec(slots[i]));
            sb.append("\n");
        }
        sb.append("     */\n");
        return sb.toString();
    }

    private static String describeSpec(IngredientSpec s) {
        if (s.isEmpty()) return "(empty)";
        if (s instanceof IngredientSpec.Item it) {
            ResourceLocation rl = BuiltInRegistries.ITEM.getKey(it.stack().getItem());
            return rl + " x" + it.stack().getCount();
        }
        if (s instanceof IngredientSpec.Tag tg) {
            return "#" + tg.tagId() + " x" + tg.count();
        }
        if (s instanceof IngredientSpec.Fluid fl) {
            FluidStack fs = fl.stack();
            ResourceLocation rl = BuiltInRegistries.FLUID.getKey(fs.getFluid());
            return rl + " " + fs.getAmount() + "mB";
        }
        if (s instanceof IngredientSpec.FluidTag ft) {
            return "#" + ft.tagId() + " " + ft.amount() + "mB";
        }
        if (s instanceof IngredientSpec.Gas g) {
            return g.gasId() + " " + g.amount() + "mB";
        }
        return s.toString();
    }
}
