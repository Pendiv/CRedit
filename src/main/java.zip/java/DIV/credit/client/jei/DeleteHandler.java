package DIV.credit.client.jei;

import DIV.credit.Credit;
import DIV.credit.client.io.ScriptWriter;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import org.jetbrains.annotations.Nullable;

/**
 * DELETE ボタンクリック処理: event.remove({id:...}) を delete.js に追記。
 * id が null の場合（dynamic / 取得失敗）は警告チャットで終了。
 */
public final class DeleteHandler {

    private DeleteHandler() {}

    public static void handle(@Nullable ResourceLocation recipeId) {
        if (recipeId == null) {
            chat(Component.translatable("gui.credit.delete.no_id").withStyle(ChatFormatting.RED));
            return;
        }
        ScriptWriter.DumpResult result = ScriptWriter.dumpDelete(recipeId.toString());
        Component msg;
        if (result instanceof ScriptWriter.DumpResult.Success s) {
            msg = Component.translatable("gui.credit.delete.success", recipeId.toString())
                .withStyle(ChatFormatting.GREEN);
        } else if (result instanceof ScriptWriter.DumpResult.Fallback f) {
            msg = Component.literal("[CraftPattern] " + f.message()).withStyle(ChatFormatting.YELLOW);
        } else {
            msg = Component.literal("[CraftPattern] " + result.message()).withStyle(ChatFormatting.RED);
        }
        chat(msg);
        if (!(result instanceof ScriptWriter.DumpResult.Failure)) {
            chat(Component.translatable("gui.credit.dump.reload_hint").withStyle(ChatFormatting.GRAY));
            playClick();
        }
        Credit.LOGGER.info("[CraftPattern] DELETE {} → {}", recipeId, result.message());
    }

    private static void chat(Component msg) {
        var p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(msg, false);
    }

    private static void playClick() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }
}
