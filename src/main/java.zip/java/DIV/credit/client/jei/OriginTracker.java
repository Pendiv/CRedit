package DIV.credit.client.jei;

import mezz.jei.api.recipe.RecipeType;
import org.jetbrains.annotations.Nullable;

/**
 * 「JEI が BuilderScreen から開かれた」flag をプロセスグローバルに保持する。
 * Shift+click で BuilderScreen → JEI に飛んだ瞬間 ON、JEI overlay が完全に閉じた瞬間 OFF。
 * <p>JEI overlay 内のページ遷移（R/U キー、ingredient クリック）は継続して active のまま。
 * <p>edit/delete ボタンの表示条件はこの flag を見る。
 */
public final class OriginTracker {

    private static volatile boolean active = false;
    @Nullable
    private static volatile RecipeType<?> originCategory = null;

    private OriginTracker() {}

    /** BuilderScreen 側 Shift+click で呼ぶ。origin = CRpatternUI を立てる。 */
    public static void enter(@Nullable RecipeType<?> originCategory) {
        active = true;
        OriginTracker.originCategory = originCategory;
    }

    /** JEI overlay の完全 close を検知した時に呼ぶ。flag 解除。 */
    public static void exit() {
        active = false;
        originCategory = null;
    }

    public static boolean isActive() {
        return active;
    }

    /** 始点となった BuilderScreen のカテゴリ（参考情報、編集モード遷移時に使う）。 */
    @Nullable
    public static RecipeType<?> getOriginCategory() {
        return originCategory;
    }
}
