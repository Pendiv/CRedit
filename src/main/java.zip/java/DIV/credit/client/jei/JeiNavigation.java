package DIV.credit.client.jei;

import DIV.credit.Credit;
import DIV.credit.jei.CraftPatternJeiPlugin;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.runtime.IJeiRuntime;
import mezz.jei.api.runtime.IRecipesGui;

import java.util.List;

/**
 * BuilderScreen → JEI 遷移ヘルパ。OriginTracker を立てて JEI を開く。
 */
public final class JeiNavigation {

    private JeiNavigation() {}

    /**
     * 指定カテゴリの JEI ビューを開く。OriginTracker = active になる。
     * @return true なら open 成功、false なら JEI 未準備等で失敗
     */
    public static boolean openCategory(IRecipeCategory<?> category) {
        if (category == null) return false;
        IJeiRuntime rt = CraftPatternJeiPlugin.runtime;
        if (rt == null) {
            Credit.LOGGER.warn("[CraftPattern] JEI not ready, cannot open category");
            return false;
        }
        RecipeType<?> type = category.getRecipeType();
        OriginTracker.enter(type);
        try {
            IRecipesGui gui = rt.getRecipesGui();
            gui.showTypes(List.of(type));
            Credit.LOGGER.info("[CraftPattern] Opened JEI for {} (origin=CRpattern)", type.getUid());
            return true;
        } catch (Exception e) {
            Credit.LOGGER.error("[CraftPattern] showTypes failed for {}", type.getUid(), e);
            OriginTracker.exit();
            return false;
        }
    }
}
